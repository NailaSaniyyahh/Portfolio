Release Log — Trace Developer sample project
Open index.html in a browser, or run python3 -m http.server 8080 in this folder.
No build, API key, external data service or account is required.

FILES
index.html: semantic sample records and progressive-enhancement controls.
assets/demo.js: combined search/category filtering, URL state and empty result UI.
assets/style.css: shared Trace Developer styles.
assets/vendor/bootstrap.min.css: Bootstrap 5.3.8 CSS (MIT license included).
assets/fonts/inter.woff2: local font (OFL license included).

CHECKS
1. Search for a term that appears in a record; only matches remain.
2. Add a category filter; both conditions must match.
3. Search for a nonexistent term; the empty state appears.
4. Reload a filtered URL; the controls and results retain that view.
5. Clear filters; all entries return and focus goes to search.
6. Disable JavaScript; all records are still readable.

LIMITATIONS
Local sample data only. No API integration, authentication, edits or persistence.
The URL stores query/filter values, not a server-side saved view.
The input is matched against text content; it is never inserted as HTML.
Keep record markup and data-category values consistent when editing.

LICENSE
Original code CC BY 3.0 — Colorlib (https://colorlib.com/).
Keep appropriate attribution, link to the license and indicate changes.
See LICENSE.txt and third-party license files for terms.
